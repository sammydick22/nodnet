run NodNet.java in the src folder
